package com.amazon.alexa.avs.message.response.speaker;

public class AdjustVolume extends VolumePayload {
}
