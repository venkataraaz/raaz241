package com.amazon.alexa.avs.message.response.speaker;

public class SetVolume extends VolumePayload {
}
