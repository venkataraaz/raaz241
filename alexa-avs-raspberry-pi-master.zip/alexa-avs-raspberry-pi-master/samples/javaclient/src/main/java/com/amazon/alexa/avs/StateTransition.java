/**
 * Copyright 2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 *
 * You may not use this file except in compliance with the License. A copy of the License is located the "LICENSE.txt"
 * file accompanying this source. This file is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the specific language governing permissions and limitations
 * under the License.
 */
package com.amazon.alexa.avs;

import java.util.Collections;
import java.util.Set;

public abstract class StateTransition<E> {

    protected Set<E> validStartStates;

    public StateTransition(Set<E> validStartStates) {
        this.validStartStates = Collections.unmodifiableSet(validStartStates);
    }

    public final void transition(State<E> currentState) {
        if (validStartStates.contains(currentState.get())) {
            onTransition(currentState);
        } else {
            onInvalidStartState(currentState);
        }
    }

    protected abstract void onTransition(State<E> state);

    protected abstract void onInvalidStartState(State<E> currentState);
}
